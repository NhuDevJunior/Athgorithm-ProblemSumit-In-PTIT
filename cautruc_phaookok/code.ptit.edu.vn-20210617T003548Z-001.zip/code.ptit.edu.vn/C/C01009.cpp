#include<stdio.h>
#include<math.h>
int main(){
    float c;
    scanf("%f",&c);
    float f=(c*9/5) + 32;
    printf("%.2f",f);
    return 0;
}
